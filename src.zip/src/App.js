import './App.css';
import InputsForm from "./components/inputs"
function App() {
  return (
    <div  className='app'>
    <InputsForm/>
    </div>
  );
}

export default App;